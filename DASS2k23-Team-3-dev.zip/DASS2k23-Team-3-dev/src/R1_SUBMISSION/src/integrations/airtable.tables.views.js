export const AirtableTablesAndViews = {
    "Templates": {
        "TABLE_ID": "tbljAZtxzbLIBfIue",
        "VIEW_ID": "viwi1hgCaxh2T4V1e"
    },
    "SnippetGroups": {
        "TABLE_ID": "tblNqzeN0QFwA1o1b",
        "VIEW_ID": "viwzRIHMiXc3MR8z2"
    }
}