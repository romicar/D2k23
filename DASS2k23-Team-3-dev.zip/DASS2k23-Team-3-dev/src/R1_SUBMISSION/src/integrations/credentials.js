export const AIRTABLE_API_KEY = "keydQDE5j9VcpPXuo"
export const AIRTABLE_BASE_ID = "appTlwUlxMRDXJ9lr"