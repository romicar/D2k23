import {OutlinedButton, TopBar} from "./CreateStyles";

function CreateTopBar() {
    return <div
        className="createPage"
    >
        <TopBar>
            Create New Template
        </TopBar>
    </div>
}

export default CreateTopBar