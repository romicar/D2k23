import { OutlinedButton, TopBar } from "../CreateStyles";

function CreateTopBar(props) {
  return (
    <div className="createPage">
      <TopBar>Create New Template</TopBar>
    </div>
  );
}

export default CreateTopBar;
