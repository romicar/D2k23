# DASS FINAL PROJECT SUBMISSION
## Team 3

## Instructions to run the code:
- `npm i` to install the node modules in the parent/current folder
- `npm start` to start the react app