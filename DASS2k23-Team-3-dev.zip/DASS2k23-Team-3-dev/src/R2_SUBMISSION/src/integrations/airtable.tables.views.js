export const AirtableTablesAndViews = {
    "Templates": {
        "TABLE_ID": "tbljAZtxzbLIBfIue",
        "VIEW_ID": "viwi1hgCaxh2T4V1e"
    },
    "SnippetGroups": {
        "TABLE_ID": "tblNqzeN0QFwA1o1b",
        "VIEW_ID": "viwzRIHMiXc3MR8z2"
    },
    "SubTemplates" : {
        "TABLE_ID": "tblnq1hLg2FIfhFKB",
        "VIEW_ID": "viw6yqTOtQ5NJawev"
    },
    "Meditations" : {
        "TABLE_ID" : "tblVSGx3BmV9EWLpH",
        "VIEW_ID" : "viwglUZ7UcQ7pyupX"
    }
}