import { OutlinedButton, TopBar } from "../CreateStyles";

function CreateTopBar(props) {
  return (
    <div className="createPage">
      <TopBar>Create New Meditation</TopBar>
    </div>
  );
}

export default CreateTopBar;
