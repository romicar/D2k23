import { OutlinedButton, TopBar } from "./CreateStyles";

function CreateTopBar() {
  return (
    <div className="createPage">
      <TopBar>Create New Meditation</TopBar>
    </div>
  );
}

export default CreateTopBar;
