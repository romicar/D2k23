import { OutlinedButton, TopBar } from "../CreateStyles";

function CreateTopBar(props) {
  return (
    <div className="createPage">
      <TopBar>Edit Template</TopBar>
    </div>
  );
}

export default CreateTopBar;
